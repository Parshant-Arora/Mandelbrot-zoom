# Mandelbrot-zoom
My CS293 course project. Implementation of Mandelbrot Zoom using SFML graphics library, and efficient use of Data Structures
